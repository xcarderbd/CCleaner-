package com.example.cleaner

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.*
import java.io.File
import java.security.MessageDigest

class MainActivity : Activity() {
    private data class Item(val file: File, val reason: String)

    private val items = mutableListOf<Item>()
    private val boxes = mutableListOf<CheckBox>()
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var scanBtn: Button
    private lateinit var cleanBtn: Button
    private val junkExt = setOf("tmp", "temp", "log", "bak", "old", "cache", "dmp", "crdownload", "part")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 90, 40, 40) }
        root.addView(TextView(this).apply { text = "Cleaner"; textSize = 28f })
        status = TextView(this).apply { text = "Tap Scan to find junk and duplicate files."; setPadding(0, 20, 0, 20) }
        scanBtn = Button(this).apply { text = "Scan"; setOnClickListener { startScan() } }
        cleanBtn = Button(this).apply { text = "Clean selected"; isEnabled = false; setOnClickListener { confirmClean() } }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(status); root.addView(scanBtn); root.addView(cleanBtn)
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askAccess() {
        if (Build.VERSION.SDK_INT >= 30)
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        else requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
    }

    private fun startScan() {
        if (!hasAccess()) {
            status.text = "Allow file access, then come back and tap Scan again."
            askAccess(); return
        }
        scanBtn.isEnabled = false; cleanBtn.isEnabled = false
        status.text = "Scanning… this can take a minute."
        Thread {
            val found = scan()
            runOnUiThread { showResults(found) }
        }.start()
    }

    private fun scan(): List<Item> {
        val root = Environment.getExternalStorageDirectory()
        val found = mutableListOf<Item>()
        val junkPaths = HashSet<String>()
        val files = root.walkTopDown()
            .onEnter { !(it.parentFile == root && it.name == "Android") }
            .filter { it.isFile }.toList()

        for (f in files) {
            val ext = f.extension.lowercase()
            val reason = when {
                f.name == ".nomedia" -> null
                f.length() == 0L -> "Empty file"
                ext in junkExt -> "Junk file (.$ext)"
                ext == "apk" && f.parentFile?.name == "Download" -> "Old installer"
                f.parentFile?.name == ".thumbnails" -> "Thumbnail cache"
                else -> null
            }
            if (reason != null) { found.add(Item(f, reason)); junkPaths.add(f.path) }
        }

        files.filter { it.path !in junkPaths && it.length() >= 10_240 }
            .groupBy { it.length() }.values.filter { it.size > 1 }
            .forEach { group ->
                group.groupBy { md5(it) }.filterKeys { it.isNotEmpty() }.values.filter { it.size > 1 }
                    .forEach { same ->
                        val sorted = same.sortedBy { it.lastModified() }
                        sorted.drop(1).forEach { found.add(Item(it, "Duplicate of ${sorted.first().name}")) }
                    }
            }
        return found
    }

    private fun md5(f: File): String = try {
        val md = MessageDigest.getInstance("MD5")
        f.inputStream().use { s ->
            val buf = ByteArray(65536)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { "" }

    private fun showResults(found: List<Item>) {
        items.clear(); items.addAll(found); boxes.clear(); list.removeAllViews()
        scanBtn.isEnabled = true
        if (found.isEmpty()) { status.text = "Nothing to clean. Your storage is tidy."; return }
        val total = found.sumOf { it.file.length() }
        status.text = "${found.size} files found, ${fmt(total)} can be freed. Untick anything you want to keep."
        found.forEach { item ->
            val cb = CheckBox(this).apply {
                text = "${item.file.name}\n${item.reason} • ${fmt(item.file.length())}"
                isChecked = true
            }
            boxes.add(cb); list.addView(cb)
        }
        cleanBtn.isEnabled = true
    }

    private fun confirmClean() {
        val chosen = items.filterIndexed { i, _ -> boxes[i].isChecked }
        if (chosen.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("Delete ${chosen.size} files?")
            .setMessage("This cannot be undone.")
            .setPositiveButton("Delete") { _, _ -> clean(chosen) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun clean(chosen: List<Item>) {
        var freed = 0L; var count = 0
        for (it in chosen) {
            val size = it.file.length()
            if (it.file.delete()) { freed += size; count++ }
        }
        cacheDir.deleteRecursively(); externalCacheDir?.deleteRecursively()
        list.removeAllViews(); items.clear(); boxes.clear(); cleanBtn.isEnabled = false
        status.text = "Deleted $count files and freed ${fmt(freed)}. Tap Scan to check again."
    }

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> "%.1f GB".format(b / 1073741824.0)
        b >= 1L shl 20 -> "%.1f MB".format(b / 1048576.0)
        else -> "%.0f KB".format(b / 1024.0)
    }
}
